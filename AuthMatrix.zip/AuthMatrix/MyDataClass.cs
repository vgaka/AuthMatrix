﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthMatrix
{
    public class MyDataClass
    {
        public string path { get; set; }
        public string actby { get; set; }
    }
    class Filter
    {
        public string Path { get; set; }
        public string Value { get; set; }
    }
}
