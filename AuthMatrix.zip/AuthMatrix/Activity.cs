﻿namespace AuthMatrix
{
    internal class Activity
    {
        public string task { get; set; }
        public string role { get; set; }
        public string responsibilities { get; set; }
    }
}