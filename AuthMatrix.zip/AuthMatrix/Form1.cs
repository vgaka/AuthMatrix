﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Response;
using FireSharp.Interfaces;
using Newtonsoft.Json.Linq;
using FireSharp;

namespace AuthMatrix
{
    public partial class Form1 : Form
    {
        //IFirebaseClient client;
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "u7L2MgXvKDJ5Bfyr0Qw2P8hlqh5TkD2KUJbRGsnA",
            BasePath = "https://api-project-935099486553.firebaseio.com/"
        };
        List<string> DName = new List<string>();
        List<string> DValue = new List<string>();
        List<string> DPath = new List<string>();
        DataTable dt = new DataTable();
        DataRow dr;
        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            IFirebaseClient client = new FirebaseClient(config);
            // get new response object
            FirebaseResponse response = client.Get("");
            JObject o = JObject.Parse(response.Body);
            // Clear existing datatable
            DPath.Clear();
            DValue.Clear();
            DName.Clear();
            dt.Clear();
            AddValtoList(o);
            //var result = !(txtsearchbox.Text.Contains(','));//false แปลว่าพบ , แต่ true แปลว่าไม่มีต้องแทรกให้
            string searchval;
                searchval = txtsearchbox.Text + ',';


                try
                {
                    List<string> slist = searchval.Split(',').ToList();


                    //อันนี้ทำงานได้                           

                    List<string> filterlist = (from d in DPath
                                               where d.Contains(slist[0].Trim().ToString())
                                               select d).ToList();

                    // จับคู่มันด้วย Zip()
                    /*
                     List<Tuple<string, string>> filterlisttuple = DPath
                            .Zip(DValue, (k, v) => new { k, v })
                            .Where(x => x.k.Contains(slist[0].Trim().ToString()) && x.k.Contains(slist[1].Trim().ToString()))
                            .Select(x => Tuple.Create(x.k, x.v))
                            .ToList();
                     */
                    //linq แบบใช้ class
                    List<Filter> filter = DPath
                            .Zip(DValue, (k, v) => new { k, v })
                            .Where(x => x.k.Contains(slist[0].Trim().ToString()) && x.k.Contains(slist[1].Trim().ToString()))
                            .Select(x => new Filter { Path = x.k, Value = x.v })
                            .ToList();

                    for (int i = 0; i < filterlist.Count(); i++)
                    {
                            
                        // loop data to object  
                        dr = dt.NewRow();
                        dr["#"] = i + 1;
                        dr["Activities"] = filter[i].Path.ToString();
                        dr["Action By"] = filter[i].Value.ToString();
                        dt.Rows.Add(dr);
                    }
                    //txtboxsearch.Text.Split(',').ToList();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    Console.WriteLine("error here");
                }
                finally
                {

                }
            //MessageBox.Show(txtsearchbox.Text); 
            //dataGridView1.DataSource = null;
            dataGridView1.DataSource = dt;
           
            


        }

            private void Form1_Load(object sender, EventArgs e)
        {
            IFirebaseClient client = new FirebaseClient(config);

            FirebaseResponse response = client.Get("");
            JObject o = JObject.Parse(response.Body);
            dt.Columns.Add("#");
            dt.Columns.Add("Activities");
            dt.Columns.Add("Action By");
            dataGridView1.DataSource = dt;
            
            //AddValtoList(o);
            /*
            string checkdata = "";
            for (int i = 0; i < DName.Count; i++)
            {
                checkdata += String.Format("{0}. {1} : {2} ({3})\n", i + 1, DName[i], DValue[i], DPath[i]);
            }
            MessageBox.Show(checkdata);
            */


        }
        private void AddVal(string n, string v, string p)
        {
            DName.Add(n);
            DValue.Add(v);
            DPath.Add(p);
        }
        private void AddValtoList(JObject o)
        {
            List<string> l1 = o.Properties().Select(p => p.Name).ToList();
            foreach (var n1 in l1)
            {
                foreach (JProperty n2 in o[n1])
                {
                    //List<string> l3 = ((JObject)o[n1]["Task"]).Properties().Select(p => p.Name).ToList();
                    foreach (JProperty n3 in o[n1][n2.Name]["Task"])
                    {
                        foreach (JProperty n4 in o[n1][n2.Name]["Task"][n3.Name])
                        {
                            foreach (JProperty n5 in o[n1][n2.Name]["Task"][n3.Name][n4.Name])
                            {
                                if (n5.Value.Type.ToString() != "String")
                                {
                                    foreach (JProperty n6 in o[n1][n2.Name]["Task"][n3.Name][n4.Name][n5.Name])
                                    {
                                        if (n6.Value.Type.ToString() != "String")
                                        {
                                            foreach (JProperty n7 in o[n1][n2.Name]["Task"][n3.Name][n4.Name][n5.Name][n6.Name])
                                            {
                                                AddVal(n7.Name, (string)n7.Value, n7.Path);
                                            }
                                        }
                                        else
                                        {
                                            AddVal(n6.Name, (string)n6.Value, n6.Path);
                                        }
                                    }
                                }
                                else
                                {
                                    AddVal(n5.Name, (string)n5.Value, n5.Path);
                                }
                            }
                        }
                    }
                }
            }
        }


    }

}